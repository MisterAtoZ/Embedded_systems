/*****defines.h*****/
#define GPIO_BASE 	0x20200000
#define GPIO_GPFSEL0 	0
#define GPIO_GPFSEL1 	1
#define GPIO_GPFSEL2 	2
#define GPIO_GPSET0 	7
#define GPIO_GPCLR0 	10
